
from fastapi import FastAPI

from pydantic import BaseModel

from agent import Agent


app = FastAPI(

    title="Local Qwen AI Agent",

    description=
    "Autonomous AI Agent powered by Qwen3-8B",

    version="1.0.0"
)


agent = Agent(
    max_steps=6
)


class AgentRequest(BaseModel):

    task: str


class AgentResponse(BaseModel):

    success: bool

    answer: str

    tools_used: list

    steps: int


@app.get("/")

def root():

    return {

        "service":
        "Local Qwen AI Agent",

        "model":
        "Qwen/Qwen3-8B",

        "status":
        "online"
    }


@app.get("/health")

def health():

    return {

        "status":
        "healthy",

        "model":
        "Qwen/Qwen3-8B",

        "agent":
        "online"
    }


@app.post(
    "/agent",
    response_model=AgentResponse
)

def run_agent(
    request: AgentRequest
):

    result = agent.run(
        request.task
    )

    return result
