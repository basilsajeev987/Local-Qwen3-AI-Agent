
class AgentMemory:

    def __init__(self, max_messages=10):

        self.messages = []

        self.max_messages = max_messages


    def add(self, role, content):

        self.messages.append(
            {
                "role": role,
                "content": content
            }
        )

        if len(self.messages) > self.max_messages:

            self.messages = self.messages[
                -self.max_messages:
            ]


    def get_context(self):

        context = ""

        for message in self.messages:

            context += f"""
{message["role"].upper()}:

{message["content"]}

"""

        return context


    def clear(self):

        self.messages = []
