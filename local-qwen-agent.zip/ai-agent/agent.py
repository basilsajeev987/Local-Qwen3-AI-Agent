
import re

from llm import agent_llm

from memory import AgentMemory

from tools import execute_tool


TOOL_DESCRIPTIONS = """

AVAILABLE TOOLS

1. calculator

Description:
Perform mathematical calculations.

Input:
A mathematical expression.

Example:

1250 * 48 / 6


2. web_search

Description:
Search the internet for current information.

Input:
A search query.

Example:

latest AI agent developments
"""


AGENT_SYSTEM_PROMPT = f"""

You are an autonomous AI agent.

You can use the following tools:

{TOOL_DESCRIPTIONS}


RULES:

1. Do not expose internal reasoning.

2. Use a tool when it is useful.

3. Never invent tool results.

4. You may use multiple tools.

5. After receiving a tool result,
continue solving the task.

6. When completed respond:

FINAL:
<answer>


7. When using a tool respond:

TOOL:
<tool_name>

INPUT:
<tool_input>

"""


class Agent:

    def __init__(self, max_steps=6):

        self.max_steps = max_steps

        self.memory = AgentMemory()

        self.tools_used = []


    # ======================================
    # BUILD PROMPT
    # ======================================

    def build_conversation(self, user_task):

        memory_context = self.memory.get_context()

        return f"""

{AGENT_SYSTEM_PROMPT}


==============================
CONVERSATION MEMORY
==============================

{memory_context}


==============================
CURRENT USER REQUEST
==============================

{user_task}


Remember:

- Use tools when necessary.
- Never invent results.
- You may use multiple tools.
- Do not expose reasoning.

If finished:

FINAL:
<answer>

"""


    # ======================================
    # PARSE TOOL
    # ======================================

    def parse_tool_request(self, response):

        tool_match = re.search(
            r"TOOL:\s*([a-zA-Z_]+)",
            response,
            re.IGNORECASE
        )

        if not tool_match:

            return None, None

        tool_name = tool_match.group(1).strip()

        input_match = re.search(
            r"INPUT:\s*(.*)",
            response,
            re.DOTALL | re.IGNORECASE
        )

        if not input_match:

            return tool_name, None

        tool_input = input_match.group(1).strip()

        if "FINAL:" in tool_input:

            tool_input = tool_input.split(
                "FINAL:"
            )[0].strip()

        return tool_name, tool_input


    # ======================================
    # PARSE FINAL
    # ======================================

    def parse_final_answer(self, response):

        final_match = re.search(
            r"FINAL:\s*(.*)",
            response,
            re.DOTALL | re.IGNORECASE
        )

        if not final_match:

            return None

        answer = final_match.group(1).strip()

        if "TOOL:" in answer:

            answer = answer.split(
                "TOOL:"
            )[0].strip()

        return answer


    # ======================================
    # RUN AGENT
    # ======================================

    def run(self, user_task):

        self.tools_used = []

        conversation = self.build_conversation(
            user_task
        )

        self.memory.add(
            "user",
            user_task
        )


        for step in range(self.max_steps):

            response = agent_llm(
                conversation
            )

            print(
                f"\n===== AGENT STEP {step + 1} ====="
            )

            print(response)


            # --------------------------
            # FINAL ANSWER
            # --------------------------

            final_answer = self.parse_final_answer(
                response
            )

            if final_answer:

                self.memory.add(
                    "assistant",
                    final_answer
                )

                return {

                    "success": True,

                    "answer": final_answer,

                    "tools_used": self.tools_used,

                    "steps": step + 1
                }


            # --------------------------
            # TOOL REQUEST
            # --------------------------

            tool_name, tool_input = \
                self.parse_tool_request(
                    response
                )


            if not tool_name:

                conversation += f"""

Your previous response was invalid.

You MUST respond using:

TOOL:
<tool_name>

INPUT:
<tool_input>

OR:

FINAL:
<answer>

"""

                continue


            if not tool_input:

                conversation += f"""

Your tool request is missing INPUT.

Correct format:

TOOL:
{tool_name}

INPUT:
<tool_input>

"""

                continue


            # --------------------------
            # EXECUTE TOOL
            # --------------------------

            result = execute_tool(
                tool_name,
                tool_input
            )

            self.tools_used.append(
                tool_name
            )


            print(
                "\nTOOL:",
                tool_name
            )

            print(
                "\nRESULT:",
                result
            )


            # --------------------------
            # FEED RESULT BACK TO LLM
            # --------------------------

            conversation += f"""

==============================
TOOL RESULT
==============================

Tool:

{tool_name}


Result:

{result}


==============================

Continue solving the user's request.

Do not invent information.

If another tool is required,
use it.

If the task is complete:

FINAL:
<answer>

"""


        return {

            "success": False,

            "answer":
            "Agent reached maximum number of steps.",

            "tools_used":
            self.tools_used,

            "steps":
            self.max_steps
        }
