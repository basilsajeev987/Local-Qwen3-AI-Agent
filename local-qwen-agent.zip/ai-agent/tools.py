
import math

from ddgs import DDGS


# ==========================================
# CALCULATOR
# ==========================================

def calculator(expression: str):

    allowed = {

        "abs": abs,
        "round": round,
        "min": min,
        "max": max,
        "pow": pow,
        "sqrt": math.sqrt,

        "sin": math.sin,
        "cos": math.cos,
        "tan": math.tan,

        "pi": math.pi
    }

    try:

        result = eval(
            expression,
            {
                "__builtins__": {}
            },
            allowed
        )

        return str(result)

    except Exception as e:

        return f"Calculator error: {e}"


# ==========================================
# WEB SEARCH
# ==========================================

def web_search(query: str, max_results=5):

    try:

        results = DDGS().text(
            query,
            max_results=max_results
        )

        formatted = []

        for result in results:

            formatted.append(
                {
                    "title": result.get(
                        "title",
                        ""
                    ),

                    "url": result.get(
                        "href",
                        ""
                    ),

                    "snippet": result.get(
                        "body",
                        ""
                    )
                }
            )

        return formatted

    except Exception as e:

        return {
            "error": str(e)
        }


# ==========================================
# TOOL REGISTRY
# ==========================================

TOOLS = {

    "calculator": calculator,

    "web_search": web_search
}


# ==========================================
# TOOL EXECUTOR
# ==========================================

def execute_tool(tool_name, tool_input):

    if tool_name not in TOOLS:

        return {
            "success": False,
            "error": f"Unknown tool: {tool_name}"
        }

    try:

        result = TOOLS[tool_name](
            tool_input
        )

        return {

            "success": True,

            "tool": tool_name,

            "input": tool_input,

            "result": result
        }

    except Exception as e:

        return {

            "success": False,

            "tool": tool_name,

            "error": str(e)
        }
